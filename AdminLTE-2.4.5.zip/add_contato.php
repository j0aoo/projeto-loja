<?php

    require('admin/config.php');

    //Pega valores do form da pagina contatos
    $nome = $_POST['nome'];
    $assunto = $_POST['assunto'];
    $tel = $_POST['tel'];
    $email = $_POST['email'];
    $msg = $_POST['msg'];


    //Inserindo na tabela notificacao
    // 0 e 1 - 0 ñ visualizada e 1 visualizada

    //Mail
    // multiple recipients
    $to  = '$email';

    // subject
    $subject = 'Preenchimento de formulario de contato';

    // message
    $message = '
    <html>
    <head>
        <title>Fashe</title>
    </head>
    <body>
        <p>Recebemos seu contato e logo estaremos respondendo</p>
    </body>
    </html>
    ';

    // To send HTML mail, the Content-type header must be set
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    // Mail it
    mail($to, $subject, $message, $headers);

?>